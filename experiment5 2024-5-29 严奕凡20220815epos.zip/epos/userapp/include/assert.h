#ifndef _ASSERT_H
#define _ASSERT_H

#define assert(e) ((void)0)

#endif /* _ASSERT_H */
